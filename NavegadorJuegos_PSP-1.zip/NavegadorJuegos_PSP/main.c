/* Navegador de Juegos para PSP / PPSSPP
 * Lista las carpetas de ms0:/PSP/GAME que tengan EBOOT.PBP y lanza la elegida.
 * Arriba/Abajo: mover   L/R: pagina   X: lanzar   Start: recargar lista
 */
#include <pspkernel.h>
#include <pspdebug.h>
#include <pspctrl.h>
#include <pspdisplay.h>
#include <pspiofilemgr.h>
#include <stdio.h>
#include <string.h>

PSP_MODULE_INFO("NavegadorJuegos", PSP_MODULE_USER, 1, 0);
PSP_MAIN_THREAD_ATTR(PSP_THREAD_ATTR_USER);

#define MAX_J 128
#define LEN_J 64
#define RAIZ "ms0:/PSP/GAME"
#define FILAS 22

static char juegos[MAX_J][LEN_J];
static int n = 0, sel = 0, activo = 1;

static int cb_salir(int a, int b, void *c) { activo = 0; return 0; }
static int hilo_cb(SceSize args, void *argp) {
    int id = sceKernelCreateCallback("salir", cb_salir, NULL);
    sceKernelRegisterExitCallback(id);
    sceKernelSleepThreadCB();
    return 0;
}
static void preparar_salida(void) {
    int t = sceKernelCreateThread("cb", hilo_cb, 0x11, 0xFA0, 0, 0);
    if (t >= 0) sceKernelStartThread(t, 0, 0);
}

static int tiene_eboot(const char *carpeta) {
    char ruta[160];
    FILE *f;
    snprintf(ruta, sizeof(ruta), "%s/%s/EBOOT.PBP", RAIZ, carpeta);
    f = fopen(ruta, "rb");
    if (!f) return 0;
    fclose(f);
    return 1;
}

static void ordenar(void) {
    int i, j;
    char tmp[LEN_J];
    for (i = 0; i < n - 1; i++)
        for (j = 0; j < n - 1 - i; j++)
            if (strcasecmp(juegos[j], juegos[j + 1]) > 0) {
                strcpy(tmp, juegos[j]);
                strcpy(juegos[j], juegos[j + 1]);
                strcpy(juegos[j + 1], tmp);
            }
}

static void escanear(void) {
    SceUID d;
    SceIoDirent e;
    n = 0; sel = 0;
    d = sceIoDopen(RAIZ);
    if (d < 0) return;
    memset(&e, 0, sizeof(e));
    while (n < MAX_J && sceIoDread(d, &e) > 0) {
        if (FIO_S_ISDIR(e.d_stat.st_mode) && e.d_name[0] != '.' && strlen(e.d_name) < LEN_J
            && tiene_eboot(e.d_name)) {
            strcpy(juegos[n++], e.d_name);
        }
        memset(&e, 0, sizeof(e));
    }
    sceIoDclose(d);
    ordenar();
}

static void lanzar(const char *carpeta) {
    char ruta[160];
    struct SceKernelLoadExecParam p;
    snprintf(ruta, sizeof(ruta), "%s/%s/EBOOT.PBP", RAIZ, carpeta);
    memset(&p, 0, sizeof(p));
    p.size = sizeof(p);
    p.args = strlen(ruta) + 1;
    p.argp = ruta;
    p.key = NULL;
    sceKernelLoadExec(ruta, &p);
}

static void dibujar(void) {
    int i, ini = (sel / FILAS) * FILAS, fin = ini + FILAS;
    pspDebugScreenClear();
    pspDebugScreenSetXY(0, 1);
    pspDebugScreenPrintf("  NAVEGADOR DE JUEGOS  -  %d encontrados\n\n", n);
    if (n == 0) {
        pspDebugScreenPrintf("  No hay juegos en %s\n  (cada juego va en su carpeta con EBOOT.PBP)\n", RAIZ);
    }
    for (i = ini; i < fin && i < n; i++)
        pspDebugScreenPrintf(" %c %s\n", i == sel ? '>' : ' ', juegos[i]);
    pspDebugScreenSetXY(0, 32);
    pspDebugScreenPrintf(" X lanzar | L/R pagina | Start recargar");
}

int main(void) {
    SceCtrlData pad;
    unsigned int prev = 0, pulsado;

    pspDebugScreenInit();
    preparar_salida();
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
    escanear();

    while (activo) {
        sceCtrlReadBufferPositive(&pad, 1);
        pulsado = pad.Buttons & ~prev;
        prev = pad.Buttons;

        if ((pulsado & PSP_CTRL_UP) && sel > 0) sel--;
        if ((pulsado & PSP_CTRL_DOWN) && sel < n - 1) sel++;
        if (pulsado & PSP_CTRL_LTRIGGER) { sel -= FILAS; if (sel < 0) sel = 0; }
        if (pulsado & PSP_CTRL_RTRIGGER) { sel += FILAS; if (sel > n - 1) sel = n - 1; if (sel < 0) sel = 0; }
        if (pulsado & PSP_CTRL_START) escanear();
        if ((pulsado & PSP_CTRL_CROSS) && n > 0) lanzar(juegos[sel]);

        dibujar();
        sceDisplayWaitVblankStart();
    }
    sceKernelExitGame();
    return 0;
}
