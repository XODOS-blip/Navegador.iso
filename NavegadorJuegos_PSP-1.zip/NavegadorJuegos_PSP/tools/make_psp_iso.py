#!/usr/bin/env python3
"""Crea un ISO de PSP (ISO9660) listo para PPSSPP a partir de un programa compilado (.prx / EBOOT sin cifrar).
Uso: python3 make_psp_iso.py programa.prx salida.iso [--title "Titulo"] [--id NERO00001] [--icon ICON0.PNG]"""
import struct, sys, datetime, argparse

SEC = 2048
now = datetime.datetime.now(datetime.timezone.utc)
b32 = lambda n: struct.pack('<I', n) + struct.pack('>I', n)
b16 = lambda n: struct.pack('<H', n) + struct.pack('>H', n)
dt7 = lambda: bytes([now.year - 1900, now.month, now.day, now.hour, now.minute, now.second, 0])
dt17 = lambda: now.strftime('%Y%m%d%H%M%S').encode() + b'00\x00'

def make_sfo(title, disc_id):
    ent = [  # (clave, formato, valor, tam_max)
        ('BOOTABLE', 'i', 1, 4), ('CATEGORY', 's', 'MG', 4), ('DISC_ID', 's', disc_id, 16),
        ('DISC_NUMBER', 'i', 1, 4), ('DISC_TOTAL', 'i', 1, 4), ('DISC_VERSION', 's', '1.00', 8),
        ('PARENTAL_LEVEL', 'i', 1, 4), ('PSP_SYSTEM_VER', 's', '1.00', 8),
        ('REGION', 'i', 32768, 4), ('TITLE', 's', title, 128)]
    ent.sort()
    keys, data, idx = b'', b'', b''
    for k, f, v, m in ent:
        koff, doff = len(keys), len(data)
        keys += k.encode() + b'\x00'
        if f == 'i':
            raw, fmt, ln = struct.pack('<I', v), 0x0404, 4
        else:
            raw, fmt = v.encode() + b'\x00', 0x0204
            ln = len(raw)
        data += raw + b'\x00' * (m - len(raw))
        idx += struct.pack('<HHIII', koff, fmt, ln, m, doff)
    keys += b'\x00' * (-len(keys) % 4)
    kstart = 20 + len(idx)
    return b'\x00PSF' + struct.pack('<IIII', 0x101, kstart, kstart + len(keys), len(ent)) + idx + keys + data

class Node:
    def __init__(s, name, is_dir, data=b''):
        s.name, s.is_dir, s.data, s.kids, s.extent, s.size, s.parent = name, is_dir, data, {}, 0, len(data), None

def build_tree(files):
    root = Node('', True)
    for path, data in files.items():
        cur = root
        parts = path.split('/')
        for p in parts[:-1]:
            if p not in cur.kids:
                n = Node(p, True); n.parent = cur; cur.kids[p] = n
            cur = cur.kids[p]
        n = Node(parts[-1], False, data); n.parent = cur; cur.kids[parts[-1]] = n
    return root

def rec(extent, size, ident, is_dir):
    n = len(ident)
    l = 33 + n + (1 if n % 2 == 0 else 0)
    r = bytes([l, 0]) + b32(extent) + b32(size) + dt7() + bytes([2 if is_dir else 0, 0, 0]) + b16(1) + bytes([n]) + ident
    return r + (b'\x00' if n % 2 == 0 else b'')

def dir_bytes(d):
    par = d.parent or d
    recs = [rec(d.extent, SEC, b'\x00', True), rec(par.extent, SEC, b'\x01', True)]
    for name in sorted(d.kids):
        k = d.kids[name]
        ident = name.encode() if k.is_dir else name.encode() + b';1'
        recs.append(rec(k.extent, k.size, ident, k.is_dir))
    out, cur = b'', b''
    for r in recs:
        if len(cur) + len(r) > SEC:
            out += cur.ljust(SEC, b'\x00'); cur = b''
        cur += r
    return out + cur.ljust(SEC, b'\x00')

def build_iso(files, volid):
    root = build_tree(files)
    dirs, queue = [], [root]
    while queue:                       # recorrido por niveles, orden alfabetico
        d = queue.pop(0); dirs.append(d)
        queue += [d.kids[n] for n in sorted(d.kids) if d.kids[n].is_dir]
    num = {id(d): i + 1 for i, d in enumerate(dirs)}
    def ptable(big):
        p = '>' if big else '<'; t = b''
        for d in dirs:
            ident = b'\x00' if d is root else d.name.encode()
            t += bytes([len(ident), 0]) + struct.pack(p + 'I', d.extent) + struct.pack(p + 'H', num[id(d.parent or root)]) + ident
            if len(ident) % 2: t += b'\x00'
        return t
    for d in dirs: d.extent = 0
    ptsize = len(ptable(False))
    pts = -(-ptsize // SEC)
    lpt, mpt = 18, 18 + pts
    cur = 18 + 2 * pts
    for d in dirs:                      # primero se asignan extensiones de directorios
        d.extent = cur
        cur += len(dir_bytes(d)) // SEC
    # el tamaño de cada dir puede depender solo del nº de entradas, no de las extensiones
    for d in dirs: d.size = len(dir_bytes(d))
    allfiles = []
    def walk(d):
        for n in sorted(d.kids):
            k = d.kids[n]
            (walk(k) if k.is_dir else allfiles.append(k))
    walk(root)
    for f in allfiles:
        f.extent = cur; cur += max(1, -(-len(f.data) // SEC))
    total = cur
    pvd = bytearray(SEC)
    pvd[0] = 1; pvd[1:6] = b'CD001'; pvd[6] = 1
    pvd[8:40] = b'PSP GAME'.ljust(32); pvd[40:72] = volid.encode().ljust(32)
    pvd[80:88] = b32(total); pvd[120:124] = b16(1); pvd[124:128] = b16(1); pvd[128:132] = b16(SEC)
    pvd[132:140] = b32(ptsize); pvd[140:144] = struct.pack('<I', lpt); pvd[148:152] = struct.pack('>I', mpt)
    pvd[156:190] = rec(root.extent, root.size, b'\x00', True)
    for o in (190, 318, 446, 574): pvd[o:o + 128] = b' ' * 128
    for o in (702, 739, 776): pvd[o:o + 37] = b' ' * 37
    pvd[813:830] = dt17(); pvd[830:847] = dt17(); pvd[847:864] = b'0' * 16 + b'\x00'; pvd[864:881] = dt17(); pvd[881] = 1
    term = bytearray(SEC); term[0] = 255; term[1:6] = b'CD001'; term[6] = 1
    img = bytearray(SEC * 16) + pvd + term
    img += ptable(False).ljust(pts * SEC, b'\x00') + ptable(True).ljust(pts * SEC, b'\x00')
    for d in dirs: img += dir_bytes(d)
    for f in allfiles: img += f.data + b'\x00' * (-len(f.data) % SEC or (SEC if not f.data else 0))
    assert len(img) == total * SEC, (len(img), total * SEC)
    return bytes(img)

def main():
    a = argparse.ArgumentParser()
    a.add_argument('programa'); a.add_argument('salida')
    a.add_argument('--title', default='Navegador de Juegos'); a.add_argument('--id', default='NERO00001')
    a.add_argument('--icon')
    o = a.parse_args()
    files = {
        'UMD_DATA.BIN': (o.id + '|0000000001|0000|G').encode(),
        'PSP_GAME/PARAM.SFO': make_sfo(o.title, o.id),
        'PSP_GAME/SYSDIR/EBOOT.BIN': open(o.programa, 'rb').read(),
    }
    if o.icon: files['PSP_GAME/ICON0.PNG'] = open(o.icon, 'rb').read()
    open(o.salida, 'wb').write(build_iso(files, 'NAVEGADOR_JUEGOS'))
    print('ISO creado:', o.salida)

if __name__ == '__main__':
    main()
