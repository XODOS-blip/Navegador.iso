#!/bin/sh
# Requiere PSPSDK (https://pspdev.github.io) y Python 3.
set -e
make clean || true
make                                   # genera NavegadorJuegos.prx y EBOOT.PBP
python3 tools/make_psp_iso.py NavegadorJuegos.prx NavegadorJuegos_PSP.iso --title "Navegador de Juegos" --id NERO00002
echo "Listo: NavegadorJuegos_PSP.iso (abrelo en PPSSPP)"
